#ifndef LIBHWAUDIO_GLOBAL_H
#define LIBHWAUDIO_GLOBAL_H

#include <stdint.h>

typedef enum _SAMPLING_RATE{
    F48kHz ,
    F96kHz  ,
    F192kHz
}SAMPLING_RATE;

typedef enum _A2BRATE{
    R48k_400KHZ,
    R48k_100KHZ,
    R44_1k_400KHZ,
    R44_1k_100KHZ
}A2BRATE;

typedef enum _A2BTXMODE{
    SINGLE,
    MASTERT,
    SLAVE0,
    SLAVE1
}A2BTXMODE;

typedef enum _ERRORTYPE{
    OPEN_ERR = -1,
    WRITE_ERR = -2,
    READ_ERR = -3,
    DDR_EMPTY_ERR = -4,
    INPUT_MODE_ERR = -5,
    OUTPUT_MODE_ERR = -6,
    AWAKEN_ERR = -7,
    A2B_CONFIG_ERR = -8,
} ERRORTYPE;

typedef struct _AudInChlInfo{
  int mode;
  int atten;
  int sampling;

} AudInChlInfo;

typedef struct _InputArg{
    char* fileName;
    int sec;
    float in_coef;
    int IS_IEPE;
} InputArg;

typedef struct _OutputArg{
    char * fileName;
    uint32_t regData;
    float out_coef;
    SAMPLING_RATE rate;
} OutputArg;

typedef struct _AudInCfg
{
    float in_coef;
    int IS_IEPE;
} AudInCfg;

typedef struct _AudOutCfg
{
    uint32_t regData;
    float out_coef;
    SAMPLING_RATE rate;
} AudOutCfg;
#ifdef __cplusplus
extern "C" {
#endif
int OpenAudio(const char* strDev, void** handle);
int GetAudioVersion(void* handle, char* pStr, int iLength, int* pActLength);
int CloseAudio(void* handle);
//input
int SetAudiAtten(void* handle, int atten);
int SetAudiAllRate(void* handle, SAMPLING_RATE samp);
int SetAudiMode(void *handle, int mode);
int SetAudiEnable(void *handle, int en);
int SetAudiFile(void *handle, InputArg *iArg);
int GetAudiStatus(void *handle, int*fileSize, int* total_len);
int GetAudiChannelInfo(void *handle, AudInChlInfo *info);
int RecvAudiData(void *handle, char* pBuf, int iLength, int* iActLen);
int RecvAudiFile(void *handle, const char* strFile, int sec);
int SetAudiCfg(void* handle, AudInCfg* cfg);
//output
int SetAudoEnable(void *handle, int en);
int SetAudoMode(void *handle, int mode);
int SetAudoAMP(void *handle, int amp);
int SetAudoFile(void *handle, OutputArg *iArg);
int SetAudoLoopPlay(void *handle, int isLoop);
int SendAudoData(void* handle, char* pBuf, int iLength, int*pActLength);
int SendAudoFile(void* handle, const char* strFile);
int SetAudoCfg(void* handle, AudOutCfg* cfg);
//A2B
int SetA2BBoardMode(void *handle, int mode);
int SetA2BTxMode(void *handle, A2BTXMODE mode, A2BRATE mRate);

int RecvA2BFile(void *handle, char * fileName, int length, float coef);
int SendA2BFile(void *handle, char * fileName, SAMPLING_RATE rate, float coef);
#ifdef __cplusplus
}
#endif



#endif // LIBHWAUDIO_GLOBAL_H
