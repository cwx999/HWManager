#include "LibHWDio_global.h"
#include <stddef.h>
int main()
{
    char str[20] = {0};
    int act = 0;
    const char* tmp = "/dev/dio_3_in";
    int temp = GetDIOVersion(tmp, str, 20, &act);
    return 0;
}
