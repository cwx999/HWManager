#ifndef LIBHWAUDIO_H
#define LIBHWAUDIO_H

#include "LibHWAudio_global.h"
#include <map>
#include <array>
#include "CommDef.h"
namespace AUDIO_DEVS {
const int MAGIC_IN = 0X3456;
const int MAGIC_OUT = 0X6543;
const int MAGIC_A2B = 0X4567;
}
class  LibHWAudio
{
public:
    enum DevOriention
    {
        DEV_INVALID = 0,
        DEV_IN,
        DEV_OUT,
        DEV_IN_OUT,
        DEV_A2B
    };
public:
    LibHWAudio(std::string strDev, int index, DevOriention eOrient);
    ~LibHWAudio();
    int initAudioDevs();
    int getAudioVersion(std::string& str);
    int uninitAudioDevs();

    uint32_t dmaRecv(uint32_t length, uint32_t addr);
    uint32_t dmaSend(uint32_t length, char *buffer, uint32_t addr);
    void registerWrite(uint32_t addr, uint32_t value);
    int registerRead(uint32_t addr);
    void regWriteFloat(uint32_t addr, float value);
    float regReadFloat(uint32_t addr);
    //input
    int setInputAtten(int channel, int atten);
    int setInputRate(SAMPLING_RATE sampling_rate);
    int setAudioInputMode(uint32_t channel, int mode);
    int setAudioInputEnable(uint32_t channel, int en);
    int setAudioInputFile(int channel, InputArg *iArg);
    int getAudioInputStatus(uint32_t channel, int * dataSize, int* total_len);
    int getAudioInputChannelInfo(uint32_t channel, AudInChlInfo *info);
    //output
    int setOutputEnable(uint32_t channel, int en);
    int setOutputMode(uint32_t channel, int mode);
    int setOutputAMP(uint32_t channel, int amp);
    int setAudioOutPut(int channel, OutputArg *iArg);
    int setLoopPlay(int channel, int isLoop);
    //A2B
    int A2BBaseRead(uint32_t addr);
    void A2BBaseWrite(uint32_t addr, int value);
    int A2BBusRead(uint32_t addr);
    void A2BBusWrite(uint32_t addr, int value);
    //
    int A2BMasterAwaken();
    int A2BBoardMode(int mode);
    int A2BConfigMask();
    int A2BInitSlave(A2BRATE mRate);
    int A2BInitMaster();

    int A2BOneSlave(A2BRATE mRate);
    int A2BTXMode(A2BTXMODE mode, A2BRATE mRate);
    //A2BTRANS
    int setA2BRecv(char * fileName, int length, float coef);
    int setA2BSend(char * fileName, SAMPLING_RATE rate, float coef);

    ///
    int getMagicNum() const;
    int getChlIndex() const;
    static bool verifyDevice(std::string strDes, std::string strSrc, int& index);
    ///
    int setAudioInputCfg(int iChannel, AudInCfg *cfg);
    int setAudioOutputCfg(int channel, AudOutCfg* cfg);
    int sendAudioData(int iChannel, char *pBuf, int iLength, int *iActLen);
    int recvAudioData(int channel, char *pBuf, int iLength, int* iActLen);
    int sendAudioFile(int iChannel, const char* strFile);
    int recvAudioFile(int iChannel, const char* strFile, int sec);
private:
    int m_iMagicNum = 0;
    std::map<int, int> m_mapDevsFD;
    int m_iConfigureFD = 0;
    int m_iDMAFD = 0;
    int m_iSlot = -1;
    int m_gain = 0;
    int m_audioSam = 0;
    int m_inputMode = 0;

    uint32_t total_read = 0;
    uint32_t len_avail = 0;
    static uint32_t m_ch;
    uint32_t arry[32] = {0};
    const int MAX_CHANNEL = 32;
    const int MCP_NUM = 4;
    char* map_user = NULL;
    char* map_dma = NULL;
    const int MAX_MAP_USER_SIZE = 65536;
    const int MAX_MAP_DMA_SIZE = 0x400000;

    int m_index = -1;
    std::string m_strDev;
};
#endif // LIBHWAUDIO_H
