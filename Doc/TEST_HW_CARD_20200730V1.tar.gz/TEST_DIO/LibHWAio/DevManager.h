#ifndef DEVMANAGER_H
#define DEVMANAGER_H
#include <string>
#include <regex.h>
#include <map>
#include <vector>
#include <memory>

struct DevInfo {
    std::string strFD;
    int iSlot = -2;
    int iChannel = -2;
};

class DevManagerAIO
{
public:
    DevManagerAIO(std::string extend = "/aio[0-8]_user",
               std::string extend2 = "/aio[0-8]_dma",
               std::string dir = "/dev");
    virtual ~DevManagerAIO(){}

    std::string getDevDescription(int iSlot, int iChannel) const;
    std::map<int, std::shared_ptr<DevInfo>> getDevDescription(int iSlot) const;
    std::string getDevConfigure(int iSlot) const;
    std::vector<int> getAioSlots() const;
    std::string getDevDma(int iSlot) const;
private:
    int trave_dir(std::string path, int depth, std::vector<std::string>& vecFiles);
    void initDevs(std::vector<std::string>& listFiles);
    void initDevsConfigure(std::vector<std::string>& listFiles);
    void initDevsConfigure(std::vector<std::string>& listFiles, std::string strPat, std::map<int, std::string>&mapItems);
private:
    std::string strDir;
    std::string strPatternExtend;
    std::string strPatternExtend2;

    std::map<int, std::map<int, std::shared_ptr<DevInfo> > > m_mapMgr;
    std::map<int, std::string> m_mapDevConfigures;
    std::map<int, std::string> m_mapDevDMAs;
    int m_matchNum = 3;
};

#endif // DEVMANAGER_H
