#ifndef LIBHWAIO_GLOBAL_H
#define LIBHWAIO_GLOBAL_H

#include <stdint.h>

typedef enum _PGIACONFIG
{
    PGIA_24_48V,
    PGIA_0_64V,
    PGIA_1_28V,
    PGIA_2_56V,
    PGIA_5_12V,
    PGIA_10_24V

}PGIACONFIG;
typedef enum _WAVEFILE{
    WAVE1,
    WAVE2,
    WAVE3,
    WAVE4
}WAVEFILE;
typedef enum _CHANNEL_MODE{
    SIGNAL_CHANNEL,
    ALL_CHANNEL
}CHANNEL_MODE;
typedef struct _INPUTINFO{
    float pgia;

} INPUTINFO;
#ifdef __cplusplus
extern "C" {
#endif
int OpenAIO(const char* strDev, void** handle);
int GetAIOVersion(void* handle, char* pStr, int iLength, int* pActLength);
int CloseAIO(void* handle);

int SetAIOInputLevelConfig(void* handle, PGIACONFIG pgia, int levelDelay, int levelAvg);
int GetAIOInputLevel(void* handle, int * arr);
int GetAIOInputLevelInfo(void* handle, INPUTINFO *info);

int SetAIOInputWaveFormConfig(void* handle, PGIACONFIG pgia, uint32_t channel);
int SetAIOInputWaveFormFileName(void* handle, char* FilePath, uint32_t length);
int GetAIOInputWaveFormStatus(void* handle, WAVEFILE buf_fd, uint32_t* buf_ddr_len, uint32_t* buf_total_read);

int SetAIOOutputLevel(void* handle, uint32_t channel, uint32_t vol);
int SetAIOOutputEnable(void* handle, int is_en, int dac_num);
int ClearOverCurrentProtectStatus(void* handle);
//pps
int SetAioPpsUpdateCount(void* handle, uint32_t sec);
int GetAioWaveCaptureTime(void* handle, uint64_t *mic_sec);
int GetAioPpsSecCount(void* handle, uint32_t *sec);
int SetAioPpsExportEnable(void* handle, int en);
int SetAioPpsEdgeSel(void* handle, int edge);
#ifdef __cplusplus
}
#endif

#endif // LIBHWAIO_GLOBAL_H
