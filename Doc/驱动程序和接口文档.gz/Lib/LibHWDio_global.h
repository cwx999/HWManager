#ifndef LIBHWDIO_GLOBAL_H
#define LIBHWDIO_GLOBAL_H
#include <stdint.h>
#ifdef __WIN__
#define DLL_API_EXPORT
#ifdef DLL_API_EXPORT
#define HWCARD_API    __declspec(dllexport)
#else
#define HWCARD_API    __declspec(dllimport)
#endif
#else
#define HWCARD_API
#endif

typedef enum _EnableStatus
{
    UNABLE_STATUS = 0,
    ENABLE_STATUS = 1
} EnableStatus;
///输出模式
typedef enum _OutputMode{
    NULL_OUTPUT_MODE = 0x00,
    LEVEL_OUTPUT_MODE = 0x01,
    PWM_OUTPUT_MODE = 0x02,
    BIT_OUTPUT_MODE = 0x03
} OutputMode;
///输出阻抗模式
typedef enum _OutputImpedanceMode
{
    HIGH_IMPEDANCE_MODE = 0,
    PULL_MODE = 0X01,
    PUSH_MODE = 0X02,
    PUSH_AND_PULL_MODE = 0X03
} OutputImpedanceMode;
///电平
typedef enum _VoltageLevel
{
    LOW_LEVEL = 0x00,
    HIGH_LEVEL = 0x01,
    INVALID_LEVEL
} VoltageLevel;
///输出参考电压
typedef enum _OutputReferenceVoltage
{
    OUTPUT_5V_REF = 0X00,
    OUTPUT_12V_REF = 0X02,
    OUTPUT_OUTSIDE_REF = 0X03
} OutputReferenceVoltage;
typedef enum _ReferenceClock
{
    REFCLK_100_MHZ = 0,
    REFCLK_20_MHZ = 1
} ReferenceClock;
///输出电平配置结构
typedef struct _DOLevelConfigure
{
    int iChannel;
    OutputImpedanceMode eMode;
    OutputReferenceVoltage eRef;
    VoltageLevel eLevel;
} DOLevelConfigure;
typedef struct _DOPWMConfigure
{
    int iChannel;
    double dFreq;
    double dDuty;
    OutputImpedanceMode eMode;
    OutputReferenceVoltage eRef;
} DOPWMConfigure;
typedef struct _DIPWMConfigure
{
    int iChannel;
    double dDurationTime;
    ReferenceClock eRefClk;
} DIPWMConfigure;
typedef struct _PWMProperty
{
    double dFreq;
    double dDuty;
} PWMProperty;
typedef struct _DOBitConfigure
{
    int iChannel;
    OutputImpedanceMode eMode;
    long lRate;
    OutputReferenceVoltage eRef;
} DOBitConfigure;
const int DIO_MAX_CHANNEL_NUM = 32;
#ifdef __cplusplus
extern "C" {
#endif

int OpenDIO(const char* strDev, void **handle);
int GetDIOVersion(void *handle, char* pStr, int iLength, int* pActLength);
int CloseDIO(void* handle);

int SetDIOChannelEnable(void *handle, int iChannel, EnableStatus eStatus);
int SetDIOAllChannelEnable(void *handle, unsigned int iStatus);
int GetDIOAllChannelEnable(void *handle, unsigned int* pStatus);
int SetDIOOutputMode(void *handle, int iChannel, OutputMode eMode);
int GetDIOOutputMode(void *handle, unsigned int* pHiMode, unsigned int* pLoMode);
int SetDIOInputReferenceVoltage(void *handle, int iChannel, int iVoltage);
int GetInputLevel(void *handle, int iChannel, int* iVoltage);
int GetAllInputLevel(void *handle, int* iLevel);
int SetOutputLevelConfigure(void *handle, DOLevelConfigure stDOLevelCfg);
int SetOutputLevel(void *handle, int iChannel, VoltageLevel eLevel);
int SetPWMCaptureEnableStatus(void *handle, int iChannel, EnableStatus eStatus);
int SetPWMAllCaptureEnableStatus(void *handle, unsigned int iStatus);
int GetPWMAllCaptureEnableStatus(void *handle, unsigned int* pStatus);
int SetOutputPWMConfigure(void *handle, DOPWMConfigure stDOPWMCfg);

int SetInputPWMConfigure(void *handle, DIPWMConfigure stDIPWMCfg);
int GetInputPWMProperty(void *handle, PWMProperty arrPWMProper[32]);

int ClearOverProtectionStatus(void *handle);

int SetOutputBitConfigure(void *handle, DOBitConfigure stDOBitCfg);
int WriteBITData(void *handle, uint64_t* pArr, int iLength);

int SetOutputDeadZone(void *handle, unsigned int iPosNs, unsigned int iNegNs);

int SetOutputPWMDutyCalibration(void *handle, int iChannel, OutputReferenceVoltage eRef, int8_t iValue);

//pps
int SetDioPpsUpdateCount(void* handle, uint32_t sec);
int GetDioBitStreamSendTime(void* handle, uint64_t *mic_sec);
int GetDioPpsSecCount(void* handle, uint32_t *sec);
int SetDioPpsExportEnable(void* handle, int en);
int SetDioPpsEdgeSel(void* handle, int edge);

#ifdef __cplusplus
}
#endif

#endif // LIBHWDIO_GLOBAL_H
