#include "DevManager.h"
#include <dirent.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <iostream>

DevManagerAIO::DevManagerAIO(std::string extend, std::string extend2, std::string dir)
    :strPatternExtend(extend),
     strPatternExtend2(extend2),
     strDir(dir)
{
    std::vector<std::string> arrFiles;
    int depth = 1;
    trave_dir(strDir, depth, arrFiles);
//    initDevs(arrFiles);
    initDevsConfigure(arrFiles);
    initDevsConfigure(arrFiles, strPatternExtend2, m_mapDevDMAs);
}

std::string DevManagerAIO::getDevDescription(int iSlot, int iChannel) const
{
    auto iter = m_mapMgr.find(iSlot);
    if(iter == m_mapMgr.end())
        return std::string();
    std::map<int, std::shared_ptr<DevInfo>> mapChannels = iter->second;
    auto itChannel = mapChannels.find(iChannel);
    if(itChannel == mapChannels.end())
        return std::string();
    return itChannel->second->strFD;
}

std::map<int, std::shared_ptr<DevInfo> > DevManagerAIO::getDevDescription(int iSlot) const
{
    auto iter = m_mapMgr.find(iSlot);
    if(iter == m_mapMgr.end())
        return std::map<int, std::shared_ptr<DevInfo>>();
    return iter->second;
}

std::string DevManagerAIO::getDevConfigure(int iSlot) const
{
    auto iter = m_mapDevConfigures.find(iSlot);
    if(iter != m_mapDevConfigures.end())
        return iter->second;
    return std::string();
}

std::string DevManagerAIO::getDevDma(int iSlot) const
{
    auto iter = m_mapDevDMAs.find(iSlot);
    if(iter != m_mapDevDMAs.end())
        return iter->second;
    return std::string();
}

std::vector<int> DevManagerAIO::getAioSlots() const
{
    std::vector<int> tmp;
    for(auto it = m_mapDevConfigures.begin(); it != m_mapDevConfigures.end(); ++it)
    {
        tmp.push_back(it->first);
    }
    return tmp;
}

int DevManagerAIO::trave_dir(std::string path, int depth, std::vector<std::string> &vecFiles)
{
    DIR *d = NULL;
    struct dirent *file = NULL;
    struct stat sb;

    if(!(d = opendir(path.c_str())))
    {
        printf("error opendir %s!!!\n",path.c_str());
        return -1;
    }
    while((file = readdir(d)) != NULL)
    {
        //把当前目录.，上一级目录..及隐藏文件都去掉，避免死循环遍历目录
        if(strncmp(file->d_name,".",1) ==0)
            continue;
        vecFiles.push_back(file->d_name);
        //判断该文件是否是目录，及是否已搜索了三层，
        if(stat(file->d_name, &sb) >= 0 && S_ISDIR(sb.st_mode) && depth <=3)
            trave_dir(file->d_name, depth +1, vecFiles);
    }
    closedir(d);
    return 0;
}

void DevManagerAIO::initDevs(std::vector<std::string> &listFiles)
{
    regex_t reg;
    regcomp(&reg, strPatternExtend.c_str(), REG_EXTENDED);
    const size_t nmatch = m_matchNum;
    regmatch_t pmatch[nmatch];

    int status = 0;
    for(auto index = listFiles.begin(); index !=listFiles.end(); index++)
    {
        status = regexec(&reg, (*index).c_str(), nmatch, pmatch, 0);
        if(status == REG_NOMATCH)
            printf("No Match\n");
        else if(status == 0)
        {
            printf("Match\n");
            std::shared_ptr<DevInfo> stInfo(new DevInfo);
            for(int ind = 0; ind < nmatch; ind++)
            {
                auto strTmp = (*index).substr(pmatch[ind].rm_so, pmatch[ind].rm_eo);
                switch(ind)
                {
                case 0:
                    stInfo->strFD = strDir + strTmp;
                    break;
                case 1:
                    stInfo->iSlot = atoi(strTmp.c_str());
                    break;
                case 2:
                    stInfo->iChannel = atoi(strTmp.c_str());
                    break;
                default:
                    break;
                    printf("\n");
                }
            }
            std::map<int, std::shared_ptr<DevInfo> > tmpChannel;
            tmpChannel.insert(std::map<int, std::shared_ptr<DevInfo> > ::value_type(stInfo->iChannel, stInfo));
            m_mapMgr.insert(std::map<int, std::map<int, std::shared_ptr<DevInfo> > > ::value_type(stInfo->iSlot, tmpChannel));
        }
    }
    regfree(&reg);
}

void DevManagerAIO::initDevsConfigure(std::vector<std::string> &listFiles, std::string strPat, std::map<int, std::string> &mapItems)
{
    regex_t reg;
    regcomp(&reg, strPat.c_str(), REG_EXTENDED);
    const size_t nmatch = 2;
    regmatch_t pmatch [nmatch];

    int status = 0;
    for(auto index = listFiles.begin(); index != listFiles.end(); index++)
    {
        status = regexec(&reg, (*index).c_str(), nmatch, pmatch, 0);
        if(status == REG_NOMATCH)
            printf("NO Match\n");
        else if(status == REG_NOERROR)
        {
            printf("Match\n");
            std::string strTmpConfigure;
            int iCard = -1;
            for(int ind = 0; ind < nmatch; ind++)
            {
                auto strTmp = (*index).substr(pmatch[ind].rm_so, pmatch[ind].rm_eo);
                switch(ind)
                {
                case 0:
                    strTmpConfigure = strDir + "/"+ strTmp;
                    break;
                case 1:
                    iCard = atoi(strTmp.c_str());
                    break;
                default:
                    break;
                    printf("\n");
                }
            }
            mapItems.insert(std::map<int, std::string>::value_type(iCard, strTmpConfigure));
        }
    }
    regfree(&reg);
}

void DevManagerAIO::initDevsConfigure(std::vector<std::string> &listFiles)
{
    ///1
    regex_t reg;
    regcomp(&reg, strPatternExtend.c_str(), REG_EXTENDED);
    const size_t nmatch = 2;
    regmatch_t pmatch [nmatch];

    int status = 0;
    ///2 进行匹配
    for (auto index = listFiles.begin(); index!=listFiles.end();index++)
    {
        status = regexec(&reg, (*index).c_str(), nmatch, pmatch, 0);
        if (status == REG_NOMATCH)
            printf("No Match\n");
        else if(status == REG_NOERROR)
        {
            printf("Match\n");
            std::string strTmpConfigure;
            int iCard = -1;
            for (int ind = 0; ind < nmatch; ind++)
            {
                auto strTmp = (*index).substr(pmatch[ind].rm_so, pmatch[ind].rm_eo);
                switch (ind)
                {
                case 0:
                    strTmpConfigure = strDir + "/" + strTmp;
                    break;
                case 1:
                    iCard = atoi(strTmp.c_str());
                    break;
                default:
                    break;
                    printf("\n");
                }
            }

            m_mapDevConfigures.insert(std::map<int, std::string>::value_type(iCard, strTmpConfigure));

        }
    }
    ///3
    regfree(&reg);
}

