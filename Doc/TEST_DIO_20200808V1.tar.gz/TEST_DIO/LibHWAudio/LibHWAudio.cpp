#include "LibHWAudio.h"
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/mman.h>
#include <cmath>
#include <xpdma.h>
#include <string.h>
#include "Wave.h"

#define min(a, b)   (((a) < (b)) ? (a) : (b))

Wave* wave = new Wave;
uint32_t LibHWAudio::m_ch = -1;
LibHWAudio::LibHWAudio(std::string strDev, int index, LibHWAudio::DevOriention eOrient)
    : m_strDev(strDev),
      m_index(index - 1)

{
    switch (eOrient) {
    case DEV_IN:
        m_iMagicNum = AUDIO_DEVS::MAGIC_IN;
        break;
    case DEV_OUT:
        m_iMagicNum = AUDIO_DEVS::MAGIC_OUT;
        break;
    case DEV_A2B:
        m_iMagicNum = AUDIO_DEVS::MAGIC_A2B;
        break;
    default:
        break;
    }
}

LibHWAudio::~LibHWAudio()
{
    if (NULL != map_user)
        {
            munmap(map_user, MAX_MAP_USER_SIZE + MAX_MAP_DMA_SIZE);
        }
        uninitAudioDevs();
}

int LibHWAudio::initAudioDevs()
{
    int ret = 0;
    ///1
    if (m_strDev.empty())
    {
        return -1;
    }

    m_iConfigureFD = open(m_strDev.c_str(), O_RDWR | O_SYNC);
    if (m_iConfigureFD < 0)
    {
        return -1;
    }

    map_user = (char*) mmap(NULL, MAX_MAP_USER_SIZE + MAX_MAP_DMA_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, m_iConfigureFD, 0);

    ///2
    m_iDMAFD = m_iConfigureFD;
    map_dma = (char*) (map_user + MAX_MAP_USER_SIZE);

    A2BBoardMode(0);
    return ret;
}

int LibHWAudio::getAudioVersion(std::string &str)
{
    int ret = 0;
    if(m_iConfigureFD == 0)
        ret = -1;
    unsigned int buf = 0;
    buf = registerRead(AUDIO_DEVS::DATETIME);
    char arr [10] = {0};
    sprintf(arr,"%x", buf);
    str = std::string(arr, 8);

    buf = registerRead(AUDIO_DEVS::VERSION);
    sprintf(arr,"%x", buf);
    str.append(std::string(arr,8));
    return ret;
}

int LibHWAudio::uninitAudioDevs()
{
    int ret = 0;
    for(auto it = m_mapDevsFD.begin(); it != m_mapDevsFD.end(); it++)
        close(it->second);
    close(m_iConfigureFD);
    XdmaClose(m_iDMAFD);
    return ret;
}

uint32_t LibHWAudio::dmaRecv(uint32_t length, uint32_t addr)
{
    int ret = -1;
    ret = XdmaRecv(m_iDMAFD, length, addr);
    if(ret !=0)
    {
        printf("dma read error %d\n", ret);

    }
    printf("read buffer (length = %d)\n", length);
}

uint32_t LibHWAudio::dmaSend(uint32_t length, char *buffer, uint32_t addr)
{
    int ret = -1;
    int i = 0;
    for(i = 0; i < length; i++)
    {
        map_dma[i] = buffer[i];
    }
    ret = XdmaSend(m_iDMAFD, length, addr);
}

void LibHWAudio::registerWrite(uint32_t addr, uint32_t value)
{
    *((volatile uint32_t *)(map_user + addr)) = value;
}

int LibHWAudio::registerRead(uint32_t addr)
{
    int reg_value = 0;
    reg_value = *((volatile uint32_t*) (map_user + addr));
    return reg_value;
}

void LibHWAudio::regWriteFloat(uint32_t addr, float value)
{
    *((volatile float *)(map_user + addr)) = value;
}

float LibHWAudio::regReadFloat(uint32_t addr)
{
    float reg_value = 0;
    reg_value = *((volatile float*) (map_user + addr));
    return reg_value;
}

int LibHWAudio::setInputAtten(int channel, int atten)
{
    int m_atten = 0;
    registerWrite(AUDIO_DEVS::IN_ENABLE, 0);
    m_atten = registerRead(AUDIO_DEVS::IN_ATTEN);
    switch (atten) {
    case 0:
        registerWrite(AUDIO_DEVS::IN_ATTEN, (~(1 << channel) ) & m_atten);
        break;
    case 1:
        registerWrite(AUDIO_DEVS::IN_ATTEN,  (1 << channel) | m_atten);
        break;
    default:
        break;
    }
    return 0;
}

int LibHWAudio::setInputRate(SAMPLING_RATE sampling_rate)
{
    registerWrite(AUDIO_DEVS::IN_ENABLE, 0);
    sleep(1);
    switch (sampling_rate) {
    case F48kHz:
        registerWrite(AUDIO_DEVS::ADC_REG_DATA, 0X2237);
        m_audioSam = 48000;
        break;
    case F96kHz:
        registerWrite(AUDIO_DEVS::ADC_REG_DATA, 0X221F);
        m_audioSam = 96000;
        break;
    case F192kHz:
        registerWrite(AUDIO_DEVS::ADC_REG_DATA, 0X2207);
        m_audioSam = 192000;
        break;
    default:
        break;
    }
    registerWrite(AUDIO_DEVS::IN_ENABLE, 0xffffffff);
    return 0;
}

int LibHWAudio::setAudioInputMode(uint32_t channel, int mode)
{
    m_inputMode = mode + 1;
    registerWrite(AUDIO_DEVS::IN_ENABLE, 0);
    usleep(1000);
    switch(channel){
    case 0:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::IN_MODE, 0);
        }else{
            registerWrite(AUDIO_DEVS::IN_MODE, 0x3);
        }
        break;
    case 1:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::IN_MODE, 0);
        }else{
            return INPUT_MODE_ERR;
        }
        break;
    case 2:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::IN_MODE, 0);
        }else{
            registerWrite(AUDIO_DEVS::IN_MODE, 0xc);
        }
        break;
    case 3:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::IN_MODE, 0);
        }else{
            return INPUT_MODE_ERR;
        }
        break;
    default:
        break;
    }
    return 0;
}

int LibHWAudio::setAudioInputEnable(uint32_t channel, int en)
{
    int m_en = 0;
    m_en = registerRead(AUDIO_DEVS::IN_ENABLE);
    switch (en) {
    case 0:
        registerWrite(AUDIO_DEVS::IN_ENABLE, (~(1 << channel) ) & m_en);
        break;
    case 1:
        registerWrite(AUDIO_DEVS::IN_ENABLE, (1 << channel) | m_en);
        break;
    default:
        break;
    }
    sleep(1);
    return 0;

}

int LibHWAudio::setAudioInputFile(int channel, InputArg *iArg)
{
    int ret = 1;
    int fd = 0;

    Wav wav;
    uint32_t len = 0;
    uint32_t min_data = 8;
    uint32_t ddr_head = 0;
    uint32_t ddr_tail = 0;
    uint32_t trans_num = 0;
    char fileName[64] = {0};
    int m_en = 0;
    strcpy(fileName, iArg->fileName);
    //long length = iArg->length;
    long length = 0;
    float coef_default = 0.00000000046566;
    float coef = 1.0;
    coef = iArg->in_coef * coef_default;
    int samp = 0;
    total_read = 0;
    len_avail = 0;
    m_ch = channel;
    if(iArg->IS_IEPE == 1){
        registerWrite(AUDIO_DEVS::BIAS_CURR_EN, 1 << channel);
       if(0 != registerRead(AUDIO_DEVS::BIAS_CURR_ERR)){
          printf("BIAS CURR ERR\n");
        }
        sleep(2);
    }
    samp = registerRead(AUDIO_DEVS::ADC_REG_DATA);
    if(samp == 0x2237){
        m_audioSam = 48000;
    }
    else if(samp == 0x221F){
        m_audioSam = 96000;
    }
    else if(samp == 0x2207){
        m_audioSam = 192000;
    }else {
        m_audioSam = 48000;
    }
    length = iArg->sec * m_audioSam * 4 * m_inputMode;
    wave->getWavHead(m_inputMode, m_audioSam, length, &wav);

    length = min(0x1FFFFFFF, length) & (~0x7);
    fd = open(fileName, O_CREAT | O_TRUNC | O_RDWR | O_SYNC, 0666);
    if(fd < 0){
        printf("open  %s failed\n",fileName);
        return OPEN_ERR;
    }

    regWriteFloat(AUDIO_DEVS::IN_MULT_COEF1 + channel *4, coef_default);
    registerWrite(AUDIO_DEVS::ADC_REG_TRIG, 1 );
    //usleep(3000000);
     m_en = registerRead(AUDIO_DEVS::IN_ENABLE);
    registerWrite(AUDIO_DEVS::IN_ENABLE, (1 << channel) | m_en);
    usleep(1000);
    trans_num = registerRead(AUDIO_DEVS::TRANS_NUM);

    int flag = 0;
    ret = write(fd, &wav,sizeof(Wav));
    if(ret < 0){
        close(fd);
        return WRITE_ERR;
    }
    // 读取环形缓冲
    while(total_read < length){
        ddr_head = registerRead(AUDIO_DEVS::DDR_HEAD_IN1 + channel * 12);
        ddr_tail = registerRead(AUDIO_DEVS::DDR_TAIL_IN1 + channel * 12);

        len_avail = (ddr_head - ddr_tail + 1 + 0x1FFFFFF) & 0x1FFFFFF;
        if(len_avail < min_data){
            usleep(1000);
            flag++;
            if(flag > 1000 && m_en != 0){
                printf("no data \n");
                return DDR_EMPTY_ERR;
            }
            continue;
        }
        len = min(len_avail, length - total_read);
        len = min(0x400000, len) & (~0x7);
        if(len > 0){
            XdmaRecv(m_iDMAFD, len, ddr_tail + 0x4000000 * channel);
            ret = write(fd, map_dma, len);
            if(ret < 0){
                printf("write read data to file %s, %d bytes, ret %d\n",fileName, len, ret);
                close(fd);
                return WRITE_ERR;
            }
        printf("write read data to file %s, %d bytes\n",fileName, ret);
        registerWrite(AUDIO_DEVS::DDR_TAIL_IN1 + channel * 12, (ddr_tail + len) & 0x1FFFFFF);
        total_read += len;
        }
    }
    if(iArg->IS_IEPE == 1){
        registerWrite(AUDIO_DEVS::BIAS_CURR_EN, 0x0);
    }
    registerWrite(AUDIO_DEVS::IN_ENABLE, 0);
    registerWrite(AUDIO_DEVS::IN_ATTEN, 0);

    close(fd);
    if(m_inputMode == 1){
        wave->WavToMono(fileName);
    }
    return 0;
}

int LibHWAudio::getAudioInputStatus(uint32_t channel, int *dataSize, int *total_len)
{
    if(m_ch == channel){
        *dataSize = total_read;
        *total_len = len_avail;
    }else{
        *dataSize = 0;
        *total_len = 0;
    }
    return 0;
}

int LibHWAudio::getAudioInputChannelInfo(uint32_t channel, AudInChlInfo *info)
{
    int samp = 0;
    info->mode = (uint16_t)registerRead(AUDIO_DEVS::IN_MODE);
    info->atten = (uint16_t)registerRead(AUDIO_DEVS::IN_ATTEN);
    samp = registerRead(AUDIO_DEVS::ADC_REG_DATA);
    if(samp == 0x2237){
        info->sampling = 48000;
    }
    else if(samp == 0x221F){
        info->sampling = 96000;
    }
    else if(samp == 0x2207){
        info->sampling = 192000;
    }else {
        info->sampling = 0;
    }
    return 0;
}

int LibHWAudio::setOutputEnable(uint32_t channel, int en)
{
    int m_en = 0;
    m_en = registerRead(AUDIO_DEVS::OUT_ENABLE);
    switch (en) {
    case 0:
        registerWrite(AUDIO_DEVS::OUT_ENABLE, (~(1 << channel) ) & m_en);
        break;
    case 1:
        registerWrite(AUDIO_DEVS::OUT_ENABLE, (1 << channel) | m_en);
        break;
    default:
        break;
    }
    return 0;
}

int LibHWAudio::setOutputMode(uint32_t channel, int mode)
{

    registerWrite(AUDIO_DEVS::OUT_ENABLE, 0);
    usleep(5000);
    switch(channel){
    case 0:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::OUT_MODE, 0);
        }else{
            registerWrite(AUDIO_DEVS::OUT_MODE, 0x3);
        }
        break;
    case 1:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::OUT_MODE, 0);
        }else{
            return OUTPUT_MODE_ERR;
        }
        break;
    case 2:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::OUT_MODE, 0);
        }else{
            registerWrite(AUDIO_DEVS::OUT_MODE, 0xc);
        }
        break;
    case 3:
        if(mode == 0){
            registerWrite(AUDIO_DEVS::OUT_MODE, 0);
        }else{
            return OUTPUT_MODE_ERR;
        }
        break;
    default:
        break;
    }
    return 0;
}

int LibHWAudio::setOutputAMP(uint32_t channel, int amp)
{
    switch(amp){
    case 0:
        registerWrite(AUDIO_DEVS::OUT_AMP, 0 << channel);
        break;
    case 1:
        registerWrite(AUDIO_DEVS::OUT_AMP, 1 << channel);
        break;
    default:
        break;
    }
    return 0;
}

int LibHWAudio::setAudioOutPut(int channel, OutputArg *iArg)
{
    int fd_out = 0;
    int ret = 0;
    long length = 0;
    uint32_t len = 0;
    uint32_t min_data = 0x100;
    uint32_t ddr_head = 0;
    uint32_t ddr_tail = 0;
    uint32_t ddr_full = 0;
    uint32_t trans_num = 0;
    int m_en = 0;
    char fileName[64] = {0};
    strcpy(fileName, iArg->fileName);
    float coef_div = 1.0;
    coef_div = iArg->out_coef;
    float mult_coef = 0.0;
    int m_samp = 0;
    uint32_t total_read = 0;
    uint32_t len_avail = 0;
    m_ch = channel;
    Wav wav;
    memset(&wav, 0, sizeof(wav));
    uint32_t reg_data = iArg->regData;
    length = wave->getFileSize(fileName) - 44;
    //usleep(10000);
    fd_out = open(fileName, O_RDWR | O_SYNC, 0666);
    if(fd_out < 0)
    {
        printf("open error\n");
        return OPEN_ERR;
    }
    lseek(fd_out, 44, SEEK_SET);
/*
    ret = read(fd_out, &wav, sizeof(wav));
    if(ret < 0){
        printf("read err ret: %d\n",ret);
        close(fd_out);
        return -2;
    }
*/
    //usleep(100000);
    length = min(0x3FFFFFFF, length) & (~0x7);
    //registerWrite(AUDIO_DEVS::OUT_ENABLE, 0x0);
    //usleep(5000);
    mult_coef = regReadFloat(AUDIO_DEVS::OUT_MULT_COEF1 + channel * 4);
    mult_coef = (float)(0x80000000) * coef_div;
    regWriteFloat(AUDIO_DEVS::OUT_MULT_COEF1 + channel * 4, mult_coef);
    if(channel <2){
        registerWrite(AUDIO_DEVS::DAC_REG_DATA0, reg_data);
        registerWrite(AUDIO_DEVS::DAC_REG_TRIG0, 1);
        switch (iArg->rate) {
        case F48kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,0);
            m_samp = 48000;
            break;
        case F96kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,1);
            m_samp = 96000;
            break;
        case F192kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,2);
            m_samp = 192000;
            break;
        default:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,0);
            m_samp = 48000;
            break;
        }
    }else{
        registerWrite(AUDIO_DEVS::DAC_REG_DATA1, reg_data);
        registerWrite(AUDIO_DEVS::DAC_REG_TRIG1, 1);
        switch (iArg->rate) {
        case F48kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,0);
            m_samp = 48000;
            break;
        case F96kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,1);
            m_samp = 96000;
            break;
        case F192kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,2);
            m_samp = 192000;
            break;
        default:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,0);
            m_samp = 48000;
            break;
        }
    }
/*
    if(m_samp != wav.fmt.SampleRate || 32 != wav.fmt.BitsPerSample){
        printf("wave err\n");
        return -5;
    }
*/
    //usleep(3000000);
     m_en = registerRead(AUDIO_DEVS::OUT_ENABLE);
    registerWrite(AUDIO_DEVS::OUT_ENABLE, (1 << channel) | m_en);
    usleep(10000);
    trans_num = registerRead(AUDIO_DEVS::TRANS_NUM);

    // 读取环形缓冲
    while(total_read < length){
        ddr_head = registerRead(AUDIO_DEVS::DDR_HEAD_OUT1 + channel * 12);
        ddr_tail = registerRead(AUDIO_DEVS::DDR_TAIL_OUT1 + channel * 12);
        ddr_full = registerRead(AUDIO_DEVS::DDR_FULL_OUT1 + channel * 12);

        if(ddr_full){
            usleep(1000);
            continue;
        }

        len_avail = (ddr_tail - ddr_head +  0x7FFFFFF) & 0x7FFFFFF;
        if(len_avail < min_data){
            usleep(1000);
            continue;
        }
        len = min(len_avail, length - total_read);
        len = min(0x400000, len) & (~0x7);

        if(len > 0){
            ret = read(fd_out, map_dma, len);
            if(ret <0){
                close(fd_out);
                return READ_ERR;
         }
         XdmaSend(m_iDMAFD, len, ddr_head + 0x10000000 + 0x8000000 * channel);
         registerWrite(AUDIO_DEVS::DDR_HEAD_OUT1 + channel *12, (ddr_head + len) & 0x7FFFFFF);
         total_read += len;
        }
    }
    close(fd_out);
    return 0;
}

int LibHWAudio::setLoopPlay(int channel, int isLoop)
{
    int m_loop = 0;
    m_loop = registerRead(AUDIO_DEVS::OUT_REPEAT);
    switch (isLoop) {
    case 0:
        registerWrite(AUDIO_DEVS::OUT_REPEAT, (~(1 << channel) ) & m_loop);
        break;
    case 1:
        registerWrite(AUDIO_DEVS::OUT_REPEAT, (1 << channel) | m_loop);
    default:
        break;
    }
}

int LibHWAudio::A2BBaseRead(uint32_t addr)
{
    uint32_t offset = 0x4108;
    registerWrite(0x4100, 2);
    registerWrite(0x4100, 1);
    registerRead(0x4104);
    registerWrite(offset, 0x01DC);
    registerWrite(offset, addr);
    registerWrite(offset, 0x1DD);
    registerWrite(offset, 0x200);
    usleep(10000);
    return registerRead( 0x410C);
}

void LibHWAudio::A2BBaseWrite(uint32_t addr, int value)
{
    uint32_t offset = 0x4108;
    registerWrite(0x4100, 2);
    registerWrite(0x4100, 1);
    registerRead(0x4104);
    registerWrite(offset, 0x01DC);
    registerWrite(offset, addr);
    registerWrite(offset, value);
    registerWrite(offset, 0x200);
    usleep(10000);
}

int LibHWAudio::A2BBusRead(uint32_t addr)
{
    uint32_t offset = 0x4108;
    registerWrite(0x4100, 2);
    registerWrite(0x4100, 1);
    registerRead(0x4104);
    registerWrite(offset, 0x01DE);
    registerWrite(offset, addr);
    registerWrite(offset, 0x1DD);
    registerWrite(offset, 0x200);
    usleep(10000);
    return registerRead( 0x410C);
}

void LibHWAudio::A2BBusWrite(uint32_t addr, int value)
{
    uint32_t offset = 0x4108;
    registerWrite(0x4100, 2);
    registerWrite(0x4100, 1);
    registerRead(0x4104);
    registerWrite(offset, 0x01DE);
    registerWrite(offset, addr);
    registerWrite(offset, value);
    registerWrite(offset, 0x200);
    usleep(10000);
}

//Master 唤醒
int LibHWAudio::A2BMasterAwaken()
{
    if((0xAD == A2BBaseRead(AUDIO_DEVS::A2B_VENDOR)) &&
       (0x28 == A2BBaseRead(AUDIO_DEVS::A2B_PRODUCT))){
           A2BBaseWrite(AUDIO_DEVS::A2B_CONTROL, 0X84);
           registerWrite(0xa00, 1);
        }
        if((0x80 == A2BBaseRead(AUDIO_DEVS::A2B_INTSRC)) &&
           (0xFF == A2BBaseRead(AUDIO_DEVS::A2B_INTTYPE))){
            return 0;  //success
        }else
            return AWAKEN_ERR; //awaken error
}

int LibHWAudio::A2BBoardMode(int mode)
{
    if(0 == mode){
        registerWrite(AUDIO_DEVS::A2B_MODE, 0);
        A2BBaseWrite(AUDIO_DEVS::A2B_CONTROL, 0);
    }
    else
       registerWrite(AUDIO_DEVS::A2B_MODE, 1);
    return 0;
}
//配置mask
int LibHWAudio::A2BConfigMask()
{
    //配置mask
    A2BBaseWrite(AUDIO_DEVS::A2B_INTMASK0, 0x77);
    A2BBaseWrite(AUDIO_DEVS::A2B_INTMASK1, 0x78);
    A2BBaseWrite(AUDIO_DEVS::A2B_INTMASK2, 0x0F);
    A2BBaseWrite(AUDIO_DEVS::A2B_BECCTL, 0xEF);
    A2BBaseWrite(AUDIO_DEVS::A2B_INTPND2, 0x01);
    //判断slave0是否激活
    A2BBaseWrite(AUDIO_DEVS::A2B_RESPCYS, 0x7B);//time
    A2BBaseWrite(AUDIO_DEVS::A2B_CONTROL, 0x81);
    A2BBaseWrite(AUDIO_DEVS::A2B_I2SGCFG, 0x20);
    A2BBaseWrite(AUDIO_DEVS::A2B_SWCTL, 0x01);
    A2BBaseWrite(AUDIO_DEVS::A2B_DISCVRY, 0x7B); //time
    A2BBaseRead(AUDIO_DEVS::A2B_INTSRC);
    A2BBaseRead(AUDIO_DEVS::A2B_INTTYPE);
    //调整switch mode 给slave编号
    A2BBaseWrite(AUDIO_DEVS::A2B_SWCTL, 0x21);
    return 0;

}

//init slave0
int LibHWAudio::A2BInitSlave( A2BRATE mRate)
{
    A2BBaseWrite(AUDIO_DEVS::A2B_NODEADDR, 0x0);
    if((0xAD == A2BBusRead(AUDIO_DEVS::A2B_VENDOR)) &&
        (0x28 == A2BBusRead(AUDIO_DEVS::A2B_PRODUCT)) &&
        (0x00 == A2BBusRead(AUDIO_DEVS::A2B_VERSION)) &&
        (0x01 == A2BBusRead(AUDIO_DEVS::A2B_CAPABILITY)) //满足条件可以初始化从1
        )
        printf("success\n");
    A2BBusWrite(AUDIO_DEVS::A2B_LDNSLOTS, 0x80);  //ldnSlot
    A2BBusWrite(AUDIO_DEVS::A2B_LUPSLOTS, 0x02);  //lupSlot

    //set frame rate & data rate
    switch(mRate){
    case R48k_400KHZ:
        A2BBusWrite(AUDIO_DEVS::A2B_I2CCFG, 0X01);
        break;
    case R48k_100KHZ:
        A2BBusWrite(AUDIO_DEVS::A2B_I2CCFG, 0X00);
        break;
    case R44_1k_400KHZ:
        A2BBusWrite(AUDIO_DEVS::A2B_I2CCFG, 0X05);
        break;
    case R44_1k_100KHZ:
        A2BBusWrite(AUDIO_DEVS::A2B_I2CCFG, 0X04);
        break;
    default:
        A2BBusWrite(AUDIO_DEVS::A2B_I2CCFG, 0X01);
        break;
    }
    //Drive SYNC Pin for I2S Operation TDM2 32bit
    A2BBusWrite(AUDIO_DEVS::A2B_I2SGCFG, 0x0020);
    //使能RX0且在BCLK下降沿采数据上升沿发数据
    A2BBusWrite(AUDIO_DEVS::A2B_I2SCFG, 0x0019);
    A2BBusWrite(AUDIO_DEVS::A2B_PDMCTL, 0x0018);

    A2BBusWrite(AUDIO_DEVS::A2B_GPIODAT, 0x0010);
    A2BBusWrite(AUDIO_DEVS::A2B_GPIOOEN, 0x0010);
    A2BBusWrite(AUDIO_DEVS::A2B_PINCFG, 0x0000);
    A2BBusWrite(AUDIO_DEVS::A2B_CLK2CFG, 0x00C1);

    A2BBusWrite(AUDIO_DEVS::A2B_DNMASK0, 0x03);

    A2BBusWrite(AUDIO_DEVS::A2B_INTMASK0, 0x0067);
    A2BBusWrite(AUDIO_DEVS::A2B_INTMASK1, 0x007F);
    A2BBusWrite(AUDIO_DEVS::A2B_BECCTL, 0x00EF);
    return 0;
}

int LibHWAudio::A2BInitMaster()
{
    A2BBaseWrite(AUDIO_DEVS::A2B_SWCTL, 1);
    A2BBaseWrite(AUDIO_DEVS::A2B_DNSLOTS, 2); //dnSlot
    A2BBaseWrite(AUDIO_DEVS::A2B_UPSLOTS, 2);//upSlot
    A2BBaseWrite(AUDIO_DEVS::A2B_I2SCFG, 0x19);
    A2BBaseWrite(AUDIO_DEVS::A2B_PINCFG, 0x00);
    A2BBaseWrite(AUDIO_DEVS::A2B_INTMASK0, 0x77);
    A2BBaseWrite(AUDIO_DEVS::A2B_INTMASK1, 0x78);
    A2BBaseWrite(AUDIO_DEVS::A2B_INTMASK2, 0x0F);
    A2BBaseWrite(AUDIO_DEVS::A2B_BECCTL, 0x0EF);
    A2BBaseWrite(AUDIO_DEVS::A2B_RESPCYS, 0x7B);//time
    A2BBaseWrite(AUDIO_DEVS::A2B_SLOTFMT, 0x044);
    A2BBaseWrite(AUDIO_DEVS::A2B_DATCTL, 0x003);
    //主模式设置new structure=1
    A2BBaseWrite(AUDIO_DEVS::A2B_CONTROL, 0x081);
    A2BBaseRead(AUDIO_DEVS::A2B_INTSRC);
    A2BBaseWrite(AUDIO_DEVS::A2B_CONTROL, 0x082);
    A2BBaseWrite(AUDIO_DEVS::A2B_NODEADDR, 0x00);

    return 0;

}

int LibHWAudio::A2BOneSlave(A2BRATE mRate)
{
    if(0 == registerRead(AUDIO_DEVS::A2B_SLAVE_BUSY)){
        A2BMasterAwaken();
        A2BConfigMask();
        A2BInitSlave(mRate);
        A2BInitMaster();
    }else{
        printf("err! aleady  one master!\n");
        return A2B_CONFIG_ERR;
    }
 return 0;
}

int LibHWAudio::A2BTXMode(A2BTXMODE mode, A2BRATE mRate)
{
    A2BOneSlave(mRate);
}

int LibHWAudio::setA2BRecv(char *fileName, int length, float coef)
{
    int fd = 0;
    int ret = 0;
    uint32_t len = 0;
    uint32_t min_data = 8;
    uint32_t ddr_head = 0;
    uint32_t ddr_tail = 0;
    uint32_t trans_num = 0;
    uint32_t blck_cnt = 0;
    uint32_t sync_cnt = 0;
    uint16_t bits_sam = 0;
    uint32_t m_rate = 0;

    total_read = 0;
    len_avail = 0;
    blck_cnt = registerRead(AUDIO_DEVS::A2B_BCLK_CNT);
    sync_cnt = registerRead(AUDIO_DEVS::A2B_SYNC_CNT);
    usleep(1000);
    if((blck_cnt != 0) && (sync_cnt !=0)){
        bits_sam = blck_cnt / (sync_cnt * 2);
        m_rate = sync_cnt * 100;
    }else{
        printf("A2Bconfig err\n");
        //return A2B_CONFIG_ERR;
    }

    Wav wav;
    wave->getWavHead(2, 48000, length, &wav);

    length = min(0x1FFFFFFF, length) & (~0x7);
    fd = open(fileName, O_CREAT | O_TRUNC | O_RDWR | O_SYNC, 0666);
    if(fd < 0){
        printf("open  %s failed\n", fileName);
        return -1;
    }
    ret = write(fd, &wav, sizeof(wav));
    if(ret < 0){
        printf("write error ret: %d]n", ret);
        close(fd);
        return WRITE_ERR;
    }
    printf("ret:%d\n",ret);

    registerWrite(AUDIO_DEVS::A2B_RX_EN, 0);
    usleep(1000);
    registerWrite(AUDIO_DEVS::A2B_RX_EN, 1);
    usleep(1000);
    if(1 == registerRead(AUDIO_DEVS::DDS_OUT_ENABLE)){
        regWriteFloat(AUDIO_DEVS::A2B_RX_MULT_COEF, 0.0000000298 );//DDS
    }else{
        regWriteFloat(AUDIO_DEVS::A2B_RX_MULT_COEF, 0.00000000046566);//DATA
    }
    trans_num = registerRead(AUDIO_DEVS::TRANS_NUM);
    // 读取环形缓冲
    int flag = 0;
    while(total_read < length){
        ddr_head = registerRead(AUDIO_DEVS::A2B_HEAD_RX);
        ddr_tail = registerRead(AUDIO_DEVS::A2B_TAIL_RX);

        len_avail = (ddr_head - ddr_tail + 0x8000000)&0x7FFFFFF;

        if(len_avail < min_data){
            usleep(1000);
            flag++;
            if(flag > 10000){
                printf("no data \n");
                return DDR_EMPTY_ERR;
            }

            continue;
        }
        len = min(len_avail, length - total_read);
        len = min(0x400000, len) & (~0x7);
        if(len > 0){
            XdmaRecv(m_iDMAFD, len, ddr_tail + 0x30000000);
            usleep(1000);
            ret = write(fd, map_dma, len);
            if(ret < 0){
                close(fd);
                return WRITE_ERR;
            }
            registerWrite(AUDIO_DEVS::A2B_TAIL_RX, (ddr_tail + len) & 0x7FFFFFF);
            total_read +=len;
        }
    }
    close(fd);
    return 0;
}

int LibHWAudio::setA2BSend(char *fileName, SAMPLING_RATE rate ,float coef)
{
    int fd = 0;
    int ret = 0;
    uint32_t len = 0;
    long length = 0;
    uint32_t min_data = 8;
    uint32_t ddr_head = 0;
    uint32_t ddr_tail = 0;
    uint32_t ddr_full = 0;
    uint32_t trans_num = 0;
    float mult_coef = 0.0;
    float coef_div = 1.0;
    uint32_t blck_cnt = 0;
    uint32_t sync_cnt = 0;
    uint16_t bits_sam = 0;
    uint32_t m_rate = 0;
    //
    total_read = 0;
    len_avail = 0;
    blck_cnt = registerRead(AUDIO_DEVS::A2B_BCLK_CNT);
    sync_cnt = registerRead(AUDIO_DEVS::A2B_SYNC_CNT);
    usleep(1000);
    if((blck_cnt != 0) && (sync_cnt !=0)){
        bits_sam = blck_cnt / (sync_cnt * 2);
        m_rate = sync_cnt * 100;
    }else{
        printf("A2Bconfig err\n");
        //return A2B_CONFIG_ERR;
    }
    coef_div = coef;
    mult_coef = regReadFloat(AUDIO_DEVS::A2B_TX_MULT_COEF);
    mult_coef = (float)(0x80000000) / coef_div; //33554432 // 0x80000000
    regWriteFloat(AUDIO_DEVS::A2B_TX_MULT_COEF, mult_coef);
    length = wave->getFileSize(fileName) - 44;
    length = min(0x1FFFFFFF, length) & (~0x7);
    fd = open(fileName, O_RDWR | O_SYNC, 0666);
    lseek(fd, 44, SEEK_SET);
    usleep(10000);

    registerWrite(AUDIO_DEVS::A2B_TX_EN, 0);
    usleep(1000);
    registerWrite(AUDIO_DEVS::A2B_TX_EN, 1);
    usleep(1000);

    if(1 == registerRead(AUDIO_DEVS::A2B_MODE)){
        switch (rate){
            case F48kHz:
                registerWrite(AUDIO_DEVS::A2B_SAMPLE_RATE, 0X0);
                break;
            case F96kHz:
                registerWrite(AUDIO_DEVS::A2B_SAMPLE_RATE, 0X1);
                break;
            case F192kHz:
                registerWrite(AUDIO_DEVS::A2B_SAMPLE_RATE, 0X2);
                break;
            default:
                break;
            }
    }else{
        switch (m_rate){
            case 48000:
                registerWrite(AUDIO_DEVS::A2B_SAMPLE_RATE, 0X0);
                break;
            case 96000:
                registerWrite(AUDIO_DEVS::A2B_SAMPLE_RATE, 0X1);
                break;
            case 192000:
                registerWrite(AUDIO_DEVS::A2B_SAMPLE_RATE, 0X2);
                break;
            default:
            registerWrite(AUDIO_DEVS::A2B_SAMPLE_RATE, 0X0);
                break;
            }
        }

    trans_num = registerRead(AUDIO_DEVS::TRANS_NUM);
    while(total_read < length){
        ddr_head = registerRead(AUDIO_DEVS::A2B_HEAD_TX);
        ddr_tail = registerRead(AUDIO_DEVS::A2B_TAIL_TX);
        ddr_full = registerRead(AUDIO_DEVS::A2B_FULL_TX);

        if(ddr_full){
            sleep(1);
            continue;
        }
        len_avail = (ddr_tail - ddr_head + 0x7FFFFFF) & 0x7FFFFFF;
        if(len_avail < min_data){
            usleep(1000);
            continue;
        }
        len = min(len_avail, length - total_read);
        len = min(0x400000,len)& (~0x7);
        if(len > 0){
            ret = read(fd, map_dma, len);
            if(ret <=0){
                close(fd);
                return READ_ERR;
         }
         XdmaSend(m_iDMAFD, len, ddr_head + 0x38000000);
         registerWrite(AUDIO_DEVS::A2B_HEAD_TX , (ddr_head + len) & 0x7FFFFFF);
         total_read += len;
        }
    }
    close(fd);
    return 0;
}

int LibHWAudio::getMagicNum() const
{
    return m_iMagicNum;
}

int LibHWAudio::getChlIndex() const
{
    return m_index;
}
#include <regex.h>
/// e.g. "^audio_([0-8])_in([0-3])"
bool LibHWAudio::verifyDevice(std::string strDes, std::string strSrc, int &index)
{
    bool isOk = false;
    ///1
    regex_t reg;
    regcomp(&reg, strDes.c_str(), REG_EXTENDED);
    const size_t nmatch = 3;
    regmatch_t pmatch [nmatch];

    int status = 0;
    ///2 进行匹配
    status = regexec(&reg, strSrc.c_str(), nmatch, pmatch, 0);
    if (status == REG_NOMATCH)
        isOk = false;
    else if(status == REG_NOERROR)
    {
        isOk = true;
        if (pmatch[2].rm_so >= 0)
        {
            std::string strTmp = strSrc.substr(pmatch[2].rm_so, pmatch[2].rm_eo - pmatch[2].rm_so);
            if (!strTmp.empty())
                index = atoi(strTmp.c_str());
        }
    }
    ///3
    regfree(&reg);
    return isOk;
}

int LibHWAudio::setAudioInputCfg(int channel, AudInCfg *cfg)
{
    int ret = 0;
    float coef_default = 0.00000000046566;
    float coef = 1.0;
    coef = cfg->in_coef * coef_default;
    int m_en = 0;
    total_read = 0;
    len_avail = 0;
    m_ch = channel;

    unsigned int buf = 0;
    registerWrite(AUDIO_DEVS::BIAS_CURR_EN, buf);
    buf = registerRead(AUDIO_DEVS::BIAS_CURR_EN);
    if(cfg->IS_IEPE == 1){
        buf = (buf | (1 << channel));

    }
    else
        buf = (buf &(~(1<< channel)));
    registerWrite(AUDIO_DEVS::BIAS_CURR_EN, buf);

    regWriteFloat(AUDIO_DEVS::IN_MULT_COEF1 + channel *4, coef_default);
    registerWrite(AUDIO_DEVS::ADC_REG_TRIG, 1 );
    m_en = registerRead(AUDIO_DEVS::IN_ENABLE);
    registerWrite(AUDIO_DEVS::IN_ENABLE, (1 << channel) | m_en);
    usleep(3000000);
    return ret;
}

int LibHWAudio::setAudioOutputCfg(int channel, AudOutCfg *cfg)
{
    int ret = 0;
    int m_en = 0;
    float coef_div = 1.0;
    coef_div = cfg->out_coef;
    float mult_coef = 0.0;
    int m_samp = 0;
    int reg_data = 0x200F;
    registerWrite(AUDIO_DEVS::IN_ENABLE, 0);
    registerWrite(AUDIO_DEVS::OUT_ENABLE, 0);
    usleep(3000000);
    mult_coef = regReadFloat(AUDIO_DEVS::OUT_MULT_COEF1 + channel * 4);
    mult_coef = (float)(0x80000000) * coef_div;
    regWriteFloat(AUDIO_DEVS::OUT_MULT_COEF1 + channel * 4, mult_coef);
    if(channel <2){
        registerWrite(AUDIO_DEVS::DAC_REG_DATA0, reg_data);
        registerWrite(AUDIO_DEVS::DAC_REG_TRIG0, 1);
        switch (cfg->rate) {
        case F48kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,0);
            m_samp = 48000;
            break;
        case F96kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,1);
            m_samp = 96000;
            break;
        case F192kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,2);
            m_samp = 192000;
            break;
        default:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE0,0);
            m_samp = 48000;
            break;
        }
    }else{
        registerWrite(AUDIO_DEVS::DAC_REG_DATA1, reg_data);
        registerWrite(AUDIO_DEVS::DAC_REG_TRIG1, 1);
        switch (cfg->rate) {
        case F48kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,0);
            m_samp = 48000;
            break;
        case F96kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,1);
            m_samp = 96000;
            break;
        case F192kHz:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,2);
            m_samp = 192000;
            break;
        default:
            registerWrite(AUDIO_DEVS::OUT_SAMMPLE_RATE1,0);
            m_samp = 48000;
            break;
        }
    }
    m_en = registerRead(AUDIO_DEVS::OUT_ENABLE);
    registerWrite(AUDIO_DEVS::OUT_ENABLE, (1 << channel) | m_en);
    usleep(3000000);
    return ret;
}

int LibHWAudio::sendAudioData(int channel, char *pBuf, int iLength, int* iActLen)
{
    int fd_out = 0;
    int ret = 0;
    long length = 0;
    uint32_t len = 0;
    uint32_t min_data = 0x100;
    uint32_t ddr_head = 0;
    uint32_t ddr_tail = 0;
    uint32_t ddr_full = 0;
    uint32_t trans_num = 0;
    uint32_t total_read = 0;
    uint32_t len_avail = 0;
    *iActLen = 0;
    const int MAX_DATA_SIZE = 0x200000;
    if (iLength >= MAX_DATA_SIZE)
        length = MAX_DATA_SIZE;
    else
        length = iLength;

    length = min(0x3FFFFFFF, length) & (~0x7);
    // 读取环形缓冲
    while(total_read < length){
        ddr_head = registerRead(AUDIO_DEVS::DDR_HEAD_OUT1 + channel * 12);
        ddr_tail = registerRead(AUDIO_DEVS::DDR_TAIL_OUT1 + channel * 12);
        ddr_full = registerRead(AUDIO_DEVS::DDR_FULL_OUT1 + channel * 12);

        if(ddr_full){
            usleep(1000);
            continue;
        }

        len_avail = (ddr_tail - ddr_head +  0x7FFFFFF) & 0x7FFFFFF;
        if(len_avail < min_data){
            usleep(1000);
            continue;
        }
        len = min(len_avail, length - total_read);
        len = min(0x400000, len) & (~0x7);

        if(len > 0){
            memcpy(map_dma, pBuf, len);
            pBuf+=len;
            length-=len;
//            ret = read(fd_out, map_dma, len);
//            if(ret <0){
//                close(fd_out);
//                return READ_ERR;
         }
         XdmaSend(m_iDMAFD, len, ddr_head + 0x10000000 + 0x8000000 * channel);
         registerWrite(AUDIO_DEVS::DDR_HEAD_OUT1 + channel *12, (ddr_head + len) & 0x7FFFFFF);
         total_read += len;
        }
    *iActLen = iLength - length;
//    close(fd_out);
    return 0;
}

int LibHWAudio::recvAudioData(int channel, char *pBuf, int iLength, int *iActLen)
{
    int ret = 1;
    int fd = 0;
    uint32_t len = 0;
    uint32_t min_data = 8;
    uint32_t ddr_head = 0;
    uint32_t ddr_tail = 0;
    uint32_t trans_num = 0;
    char fileName[64] = {0};
    int m_en = 0;
    long length = iLength;
    char* pBufTmp = pBuf;
    total_read = 0;
    len_avail = 0;
    int flag = 0;
    *iActLen = 0;
    // 读取环形缓冲
    while(total_read < length){
        ddr_head = registerRead(AUDIO_DEVS::DDR_HEAD_IN1 + channel * 12);
        ddr_tail = registerRead(AUDIO_DEVS::DDR_TAIL_IN1 + channel * 12);

        len_avail = (ddr_head - ddr_tail + 1 + 0x1FFFFFF) & 0x1FFFFFF;
        if(len_avail < min_data){
            usleep(1000);
            flag++;
            if(flag > 1000 ){
                printf("no data \n");
                return DDR_EMPTY_ERR;
            }
            continue;
        }
        len = min(len_avail, length - total_read);
        len = min(0x400000, len) & (~0x7);
        if(len > 0){
            XdmaRecv(m_iDMAFD, len, ddr_tail + 0x4000000 * channel);
            memcpy(pBufTmp, map_dma, len);
            length-=len;
            pBufTmp+=len;
            if(ret < 0){
                printf("write read data to file %s, %d bytes, ret %d\n",fileName, len, ret);
                close(fd);
                return WRITE_ERR;
            }
        printf("write read data to file %s, %d bytes\n",fileName, ret);
        registerWrite(AUDIO_DEVS::DDR_TAIL_IN1 + channel * 12, (ddr_tail + len) & 0x1FFFFFF);
        total_read += len;
        }
    }
    //registerWrite(AUDIO_DEVS::BIAS_CURR_EN, 0x0);

//    registerWrite(AUDIO_DEVS::IN_ENABLE, 0);
//    registerWrite(AUDIO_DEVS::IN_ATTEN, 0);
    *iActLen = iLength - length;
//    close(fd);
//    if(m_inputMode == 1){
//        wave->WavToMono(fileName);
//    }
    return 0;
}

int LibHWAudio::sendAudioFile(int iChannel, const char *strFile)
{
    int status = 0;
    int fd_out = open(strFile, O_RDWR | O_SYNC, 0666);
    if(fd_out < 0)
    {
        printf("open error\n");
        return OPEN_ERR;
    }
    lseek(fd_out, 44, SEEK_SET);
    char *arr  = (char *) malloc(20480);
    int len = 0;
    int iActLen = 0;
    while(len = read(fd_out, arr, 20480))
    {
        sendAudioData(iChannel, arr, len, &iActLen);
    }
    free(arr);
    close(fd_out);
    return status;
}

int LibHWAudio::recvAudioFile(int iChannel, const char *strFile, int sec)
{
    int status = 0;
    Wav wav;
    FILE* fp = fopen(strFile, "wb");
    if(fp == NULL)
    {
        printf("open error\n");
        return OPEN_ERR;
    }
//    lseek(fd_out, 44, SEEK_SET);
    int samp = registerRead(AUDIO_DEVS::ADC_REG_DATA);
    if(samp == 0x2237){
        m_audioSam = 48000;
    }
    else if(samp == 0x221F){
        m_audioSam = 96000;
    }
    else if(samp == 0x2207){
        m_audioSam = 192000;
    }else {
        m_audioSam = 48000;
    }

    long length = sec * m_audioSam * 4 * (m_inputMode+1);
    wave->getWavHead(m_inputMode, m_audioSam, length, &wav);
    fwrite(&wav, sizeof(wav), 1, fp);
    char *arr  = (char *) malloc(2048);
    int len = 0;
    do {
        recvAudioData(iChannel, arr, 2048, &len);
        fwrite(arr, 1, len, fp);
    }
    while (len && (ftell(fp)<=length));
    registerWrite(AUDIO_DEVS::BIAS_CURR_EN, 0x0);
    free(arr);
    fclose(fp);
    return status;
}

