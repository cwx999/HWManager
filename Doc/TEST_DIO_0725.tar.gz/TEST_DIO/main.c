#include "LibHWDio_global.h"
#include <stddef.h>
#include <stdio.h>
int main()
{
    char str[20] = {0};
    int act = 0;
    const char* tmp = "/dev/dio_3_in";
    void * pHandle = NULL;
    int temp = OpenDio(tmp, &pHandle);
    printf("1:::%u", pHandle);
    temp = GetDioVersion(pHandle, str, 20, &act);
    printf("2:::%u", pHandle);
    return 0;
}
